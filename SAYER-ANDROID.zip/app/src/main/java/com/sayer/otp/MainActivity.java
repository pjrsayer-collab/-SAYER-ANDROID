
package com.sayer.otp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    private FirebaseAuth auth;
    private EditText phoneInput, codeInput;
    private TextView status;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(30, 30, 30, 30);
        layout.setBackgroundColor(Color.rgb(12, 18, 32));

        TextView title = new TextView(this);
        title.setText("SAYER");
        title.setTextSize(38);
        title.setTextColor(Color.CYAN);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("ورود به پیام‌رسان SAYER");
        subtitle.setTextSize(18);
        subtitle.setTextColor(Color.WHITE);
        subtitle.setGravity(Gravity.CENTER);

        phoneInput = new EditText(this);
        phoneInput.setHint("شماره با کد کشور، مثال +937XXXXXXXX");
        phoneInput.setTextColor(Color.WHITE);
        phoneInput.setHintTextColor(Color.LTGRAY);
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);

        Button sendButton = new Button(this);
        sendButton.setText("ارسال کد تأیید");

        codeInput = new EditText(this);
        codeInput.setHint("کد پیامک‌شده");
        codeInput.setTextColor(Color.WHITE);
        codeInput.setHintTextColor(Color.LTGRAY);
        codeInput.setInputType(InputType.TYPE_CLASS_NUMBER);

        Button verifyButton = new Button(this);
        verifyButton.setText("تأیید و ورود");

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);

        layout.addView(title);
        layout.addView(subtitle);
        layout.addView(phoneInput);
        layout.addView(sendButton);
        layout.addView(codeInput);
        layout.addView(verifyButton);
        layout.addView(status);

        setContentView(layout);

        sendButton.setOnClickListener(v -> sendCode());
        verifyButton.setOnClickListener(v -> verifyCode());
    }

    private void sendCode() {
        String phone = phoneInput.getText().toString().trim();

        if (!phone.matches("^\\+[1-9][0-9]{7,14}$")) {
            status.setText("شماره را با کد کشور وارد کن.");
            return;
        }

        status.setText("در حال ارسال کد...");

        PhoneAuthOptions options =
            PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phone)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                    @Override
                    public void onVerificationCompleted(PhoneAuthCredential credential) {
                        signIn(credential);
                    }

                    @Override
                    public void onVerificationFailed(FirebaseException e) {
                        status.setText("خطا: " + e.getMessage());
                    }

                    @Override
                    public void onCodeSent(String id,
                        PhoneAuthProvider.ForceResendingToken token) {
                        verificationId = id;
                        status.setText("کد ارسال شد. کد را وارد کن.");
                    }
                })
                .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyCode() {
        String code = codeInput.getText().toString().trim();

        if (verificationId == null || code.length() != 6) {
            status.setText("ابتدا کد پیامکی را دریافت و وارد کن.");
            return;
        }

        PhoneAuthCredential credential =
            PhoneAuthProvider.getCredential(verificationId, code);

        signIn(credential);
    }

    private void signIn(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this, task -> {
                if (task.isSuccessful()) {
                    status.setText("ورود موفق بود! به SAYER خوش آمدی.");
                } else {
                    status.setText("کد تأیید نشد. دوباره بررسی کن.");
                }
            });
    }
}

