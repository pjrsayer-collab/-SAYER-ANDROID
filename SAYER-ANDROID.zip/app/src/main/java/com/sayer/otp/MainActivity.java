package com.sayer.otp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(1);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.rgb(8,13,24));

        TextView logo = new TextView(this);
        logo.setText("S");
        logo.setTextSize(85);
        logo.setTextColor(Color.CYAN);
        logo.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("SAYER OTP");
        title.setTextSize(30);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("خوش آمدید به برنامه SAYER");
        subtitle.setTextSize(17);
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);

        layout.addView(logo);
        layout.addView(title);
        layout.addView(subtitle);

        setContentView(layout);
    }
}
